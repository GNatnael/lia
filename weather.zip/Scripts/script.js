

var weather_apikey = '&appid=9a7c18246509882a3780f2a616414704';
var units = '&units=metric'
var lang = '&lang=sv'

var idlocation = '2661886'
var plats = 'stockholm';
plats = getQueryStringParameter('MyString');
var weatherRequest = 'https://api.openweathermap.org/data/2.5/$safeprojectname$?q=' +plats +weather_apikey +units +lang
var apiUrl = 'https://api.openweathermap.org/data/2.5/forecast?id=' +idlocation +weather_apikey +units +lang

var reslutat = [];
var veckodagar = ['Söndag', 'Måndag', 'Tisdag', 'Onsdag', 'Torsdag', 'Freday', 'Lördag'];


var ourForecastRequest = new XMLHttpRequest();
ourForecastRequest.open("GET", apiUrl, true);
ourForecastRequest.onload = function (e) {
  if (ourForecastRequest.readyState === 4) {
    if (ourForecastRequest.status === 200) {

      var data = JSON.parse(this.responseText);
      var count = Object.keys(data.list).length;


      for(var i = 6; i< count; i+=8){
        const temp = new Forecast (data.list[i].dt_txt.substring(0, 10),
                                       data.list[i].$safeprojectname$[0].icon,
                                       data.list[i].main.temp_max,
                                       data.list[i].main.temp_min)
                                       reslutat.push(temp);
                                      
      }

      let [dayOne, dayTwo, dayThree, dayfour, dayfive] = [reslutat[0], reslutat[1], reslutat[2], reslutat[3], reslutat[4]]



      var day1 = new Date(dayOne.date);
      var dayName1 = veckodagar[day1.getDay()];

      var day2 = new Date(dayTwo.date);
      var dayName2 = veckodagar[day2.getDay()];

      var day3 = new Date(dayThree.date);
      var dayName3 = veckodagar[day3.getDay()];

      var day4 = new Date(dayfour.date);
      var dayName4 = veckodagar[day4.getDay()];

      var day5 = new Date(dayfive.date);
      var dayName5 = veckodagar[day5.getDay()];


      dayOne.date = dayName1.substring(0, 3);
      dayTwo.date = dayName2.substring(0, 3);
      dayThree.date = dayName3.substring(0, 3);
      dayfour.date = dayName4.substring(0, 3);
      dayfive.date = dayName5.substring(0, 3);

      getWeather("date1",dayOne.date);
      getWeather("tempMax1",dayOne.tempMax + "<span>°</span>");
      getWeather("tempMin1",dayOne.tempMin + "<span>°</span>");
      getIcon("icon1",'../images/ikoner/' + dayOne.icon + '.svg');

      getWeather("date2",dayTwo.date);
      getWeather("tempMax2",dayTwo.tempMax + "<span>°</span>");
      getWeather("tempMin2",dayTwo.tempMin + "<span>°</span>");
      getIcon("icon2",'../images/ikoner/' + dayTwo.icon + '.svg');

      getWeather("date3",dayThree.date);
      getWeather("tempMax3",dayThree.tempMax + "<span>°</span>");
      getWeather("tempMin3",dayThree.tempMin + "<span>°</span>");
      getIcon("icon3",'../images/ikoner/' + dayThree.icon + '.svg');

      getWeather("date4",dayfour.date);
      getWeather("tempMax4",dayfour.tempMax + "<span>°</span>");
      getWeather("tempMin4",dayfour.tempMin + "<span>°</span>");
      getIcon("icon4",'../images/ikoner/' + dayfour.icon + '.svg');

      getWeather("date5",dayfive.date);
      getWeather("tempMax5",dayfive.tempMax + "<span>°</span>");
      getWeather("tempMin5",dayfive.tempMin + "<span>°</span>");
      getIcon("icon5",'../images/ikoner/' + dayfive.icon + '.svg');


    } else {
      console.error(ourForecastRequest.statusText);
    }
  }
};
ourForecastRequest.onerror = function (e) {
  console.error(ourForecastRequest.statusText);
};
ourForecastRequest.send(null);

///////////////////////////////////////////////////////////////////
//                                                              //
//                Hämta dagens väderprognos                     //
//                                                              //
//////////////////////////////////////////////////////////////////

var myRequest = new XMLHttpRequest();
myRequest.open("GET", weatherRequest, true);
myRequest.onload = function (e) {
  if (myRequest.readyState === 4) {
    if (myRequest.status === 200) {
      var todaysData = JSON.parse(this.responseText);

      getWeather("myLocation",todaysData.name);
      getWeather("description",todaysData.$safeprojectname$[0].description);
      getWeather("temperature",todaysData.main.temp + "<span>°</span>");
      getWeather("windSpeed","Vindstyrka : " + todaysData.wind.speed +" m/s");
      getWeather("winddeg","Vindriktning: " + todaysData.wind.deg + "°");
      getIcon("bigIcon",'../images/ikoner/' + todaysData.$safeprojectname$[0].icon +'.svg');
      
    } else {
      console.error(myRequest.statusText);
    }
  }
};
myRequest.onerror = function (e) {
  console.error(myRequest.statusText);
};
myRequest.send(null);

