function getWeather(id,resultat){
  document.getElementById(id).innerHTML=resultat;
}﻿

function getIcon(id,resultat){
  document.getElementById(id).src=resultat;
}﻿

function Forecast(date, icon, temp_max, temp_min) {
   this.date = date;
   this.icon = icon;
   this.tempMax = temp_max;
   this.tempMin = temp_min;
   }


   function datumtid() {
     var d = new Date(),
         months = ['Jan','Feb','Mar','Apr','Maj','Jun','Jul','Aug','Sep','Okt','Nov','Dec'],
         days = ['Sön','Mån','Tis','Ons','Tor','Fre','Lör'];
     return days[d.getDay()]+' '+d.getDate()+' '+months[d.getMonth()]+' '+d.getFullYear();
   }
   document.getElementById("datum").innerHTML = datumtid();


   function checkTime(i) {
     if (i < 10) {
       i = "0" + i;
     }
     return i;
   }
   
   function startTime() {
     var today = new Date();
     var h = today.getHours();
     var m = today.getMinutes();
     var s = today.getSeconds();
     // add a zero in front of numbers<10
     m = checkTime(m);
     s = checkTime(s);
     document.getElementById('time').innerHTML = h + ":" + m + ":" + s;
     t = setTimeout(function() {
       startTime()
     }, 500);
   }
   startTime();


   function getQueryStringParameter(urlParameterKey) {
       var params = document.URL.split('?')[1].split('&');
       var strParams = '';
       for (var i = 0; i < params.length; i = i + 1) {
           var singleParam = params[i].split('=');
           if (singleParam[0] == urlParameterKey)
               return decodeURIComponent(singleParam[1]);
       }
   }
